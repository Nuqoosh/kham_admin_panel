"use client";

import { CustomerForm } from "@/components/forms/customer-form";

export default function NewCustomerPage() {
  return <CustomerForm mode="create" />;
}
